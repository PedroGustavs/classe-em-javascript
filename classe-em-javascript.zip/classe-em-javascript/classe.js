    class Heroi {
        constructor(nome, idade, tipo) {
            this.nome = nome;
            this.idade = idade;
            this.tipo = tipo;
            this.verificarAtaque();
        }

        verificarAtaque(){
        
            if(tipo === 'Mago'){
                this.ataque = 'Magia';
            } else if(tipo === 'Guerreiro'){
                this.ataque = 'Espada';
            } else if(tipo === 'Monge'){
                this.ataque = 'Artes marciais';
            } else if(tipo === 'Ninja'){
                this.ataque = 'Shuriken';
            }
            else{
                this.ataque = 'Outra ferramenta';
            }
        }

        atacar(){
            console.log("O "+this.tipo+" atacou usando "+this.ataque);
        }
    }


    let nome = prompt("Por favor gentileza, informe o seu nome:");
    let idade = parseInt(prompt("Por favor gentileza, informe a sua idade:"));
    let tipo = prompt("Por favor gentileza, informe o seu tipo:");

    const hr = new Heroi(nome, idade, tipo);
    hr.atacar();